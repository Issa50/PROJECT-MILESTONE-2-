﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using DataCapture.Data; 
namespace DataCapture.Data
{
    public class App_settings
    {
        public static string ConnectionString()
        {
            return ConfigurationManager.ConnectionStrings["StudentModuleEntitiese"].ConnectionString;
        }
    }
}
