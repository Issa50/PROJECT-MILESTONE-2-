USE [StudentModule]
GO

/****** Object:  Table [dbo].[Modules]    Script Date: 17/11/2022 5:24:20 pm ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Modules](
	[ModulesCode] [int] IDENTITY(1,1) NOT NULL,
	[ModulesName] [varchar](50) NULL,
	[ModulesDescription] [varchar](100) NULL,
	[OnlineResources] [varchar](300) NULL,
 CONSTRAINT [PK_Modules] PRIMARY KEY CLUSTERED 
(
	[ModulesCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


